import React, {useEffect, useRef, useState} from "react";
// import {SelectProps} from './select.props'
import classNames from "../../utils/helpers/class-names";
import {COLORS, HOVER_COLORS, LABEL_SIZES, VARIANTS} from "./select.style";
import StartAdornment from './StartAdornment'
import TickIcon from "./Tick";
import {Text} from "@pezeshk-book/ui-kit";

export const Select = ({size = 'medium', defaultText = 'متن ورودی', optionsList, value  , onChange, id, text, color = 'primary', variant = 'outlined', disabled, error}: any) => {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const dropDownRef = useRef<HTMLDivElement>(null);

  // const [selectedText, setSelectedText] = useState<string>(defaultText || 'Select')
  const [selectedText, setSelectedText] = useState<string>('')
  const [show, setShow] = useState<boolean>(false)


  //
  // useEffect(() => {
  //   if (value) {
  //     let val = optionsList.find((item) => {
  //       if (item[id] == value) {
  //         return item[text]
  //       }
  //     });
  //     setSelectedText(val[text] || ( 'Select'))
  //   } else {
  //     setSelectedText(defaultText || 'Select')
  //   }
  // }, [value])

  // useEffect(() => {
    // if (value) {
    //   let val = optionsList.find((item) => {
    //     if (item[id] == value) {
    //       return item[text]
    //     }
    //   });
    //   setSelectedText(val)
    //   // setSelectedText(val[text])
    // } else {
    //   setSelectedText('')
    // }

    // console.log(value)
  // }, [value])

  useEffect(()=>{
    console.log(value)
  })


  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [])

  const handleClickOutside = (event: any) => {
    if (wrapperRef.current && !wrapperRef.current.contains(event.target) && dropDownRef.current && !dropDownRef.current.contains(event.target)) {
      setShow(false)
    }
  };


  // prevState => !prevState
  const handleListDisplay = () => {
    disabled ? setShow(false) : setShow(prev => !prev)
  };


  const handleOptionClick = (e: any) => {
    setShow(false)

    setSelectedText(e.target.innerText)
    onChange(e.target.getAttribute("data-name"))
  };


  return (
      <div ref={wrapperRef} className={classNames('flex flex-col items-start justify-between rounded-lg relative w-full h-auto',          // COLORS[color],
        // COLORS[color]
      )}>


        <div
          onClick={handleListDisplay}
          className={classNames('flex justify-between items-center w-full border cursor-pointer rounded-lg px-4 py-4 ',
            disabled && '!cursor-not-allowed !bg-control-100',
            error && '!border-danger',
            COLORS[color],
            // SIZES[size],
            !disabled && VARIANTS({variants: variant})
          )}>
          <StartAdornment/>
          {/*<div className={'flex justify-center items-center h-full !bg-grey-300 w-full'}>*/}
          <Text color={'grey.800'} typography={'sm'}  className={classNames("select-none grow right-[50px] bg-transparent absolute !text-xl  duration-200",
            selectedText !== '' ? ' duration-200 h-auto translate-y-[-50%] bg-white translate-x-0 right-[9px] top-0' : '',
            LABEL_SIZES[size],
          )}
          >
            {defaultText}
          </Text>
          {/*</div>*/}

          {selectedText !== '' && (
            <Text typography={'base'} align={'right'} color={'grey.800'} className={'grow mr-2 select-none'}>
              {selectedText}
            </Text>
          )}

          {/*<ArrowDownIcon show={show}/>*/}
          <svg className={`${disabled ? '!stroke-grey-400' : 'currentColor'}  ${show ? 'rotate-0 duration-150' : 'rotate-180 duration-150'}`} width="18" height="9" viewBox="0 0 18 9" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.92 8.04999L10.4 1.52999C9.63002 0.759987 8.37002 0.759987 7.60002 1.52999L1.08002 8.04999"  strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>


        {/*  dropdown*/}


        <div ref={dropDownRef} className={`flex md:flex flex-col  bottom-0 w-full fixed md:absolute md:top-full -translate-y-5 left-0 w-full bg-white border border-b-0 border-x-0 md:border text-[#6B6B6B] rounded-tr-lg rounded-tl-lg md:rounded-lg transition-all duration-200  shadow-lg z-40 px-4 py-4 ${show ? "fixed -translate-y-0 transition-all md:block md:absolute md:translate-0 md:h-fit"
          : "translate-y-full md:-translate-x-0 transition-all md:hidden"}`}>
          {optionsList.map(option => (
            <div className={classNames('border md:border-0 border-x-0 px-2 border-t-0 flex justify-between items-center hover:bg-[#E1E1E1] md:rounded cursor-pointer',
              option[text] === selectedText ? 'bg-control-100 hover:bg-control-100' : 'bg-white',
              HOVER_COLORS[color]
            )}
                 key={option[id]}
            >
              <Text
                color={`${option[text] === selectedText ? 'grey.800' : '!red.600'}`}
                align={'right'}
                type={`${option[text] === selectedText ? 'bold' : ''}`}
                typography={'sm'}
                data-name={option[id]}
                key={option[id]}
                onClick={(event) => handleOptionClick(event)}
                className={`font-bold grow py-2 select-none`}

              >
                {option[text]}
              </Text>

              {option[text] === selectedText && <TickIcon/>}
            </div>
          ))}
        </div>
        {error ? (
          <Text color={'danger'} typography={'xs'} className={'mr-3 select-none'}>
            متن خطا
          </Text>
        ) : (
          <Text color={'grey.600'} typography={'xs'} className={'mr-3 select-none'}>
            متن راهنما
          </Text>
        )}
      </div>

  )
}

export default Select;
