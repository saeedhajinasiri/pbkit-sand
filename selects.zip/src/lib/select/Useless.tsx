// import classNames from "../../utils/helpers/class-names";
// import {COLORS, HOVER_COLORS, LABEL_SIZES, VARIANTS} from "./select.style";
// import StartAdornment from "./StartAdornment";
// import TickIcon from "./Tick";
// import React, {useState} from "react";

// const Useless = () => {
//   return(
    // <div>
    //
    //   <div ref={wrapperRef} className={classNames('mb-96 flex items-center justify-between rounded-lg relative w-full h-auto',          // COLORS[color],
    //     // COLORS[color]
    //   )}>
    //
    //
    //     <div
    //       onClick={handleListDisplay}
    //       className={classNames('flex justify-between items-center w-full border cursor-pointer rounded-lg px-4 py-4 ',
    //         disabled && 'cursor-not-allowed !bg-control-100',
    //         COLORS[color],
    //         // SIZES[size],
    //         VARIANTS({variants: variant})
    //       )}>
    //       <StartAdornment/>
    //       {/*<div className={'flex justify-center items-center h-full !bg-grey-300 w-full'}>*/}
    //       <div className={classNames("grow right-[50px] bg-transparent absolute  duration-200",
    //         selectedText !== '' ? ' duration-200 h-auto translate-y-[-60%] bg-white translate-x-0 right-[9px] top-0' : '',
    //         LABEL_SIZES[size],
    //
    //
    //       )}
    //       >
    //         {defaultText}
    //       </div>
    //       {/*</div>*/}
    //
    //       {selectedText !== '' && (
    //         <p className={'text-right text-base grow mr-2 text-[#121212]'}>
    //           {selectedText}
    //         </p>
    //       )}
    //
    //       {/*<ArrowDownIcon show={show}/>*/}
    //       <svg className={`${show ? 'rotate-0 duration-150' : 'rotate-180 duration-150'}`} width="18" height="9" viewBox="0 0 18 9" fill="none" xmlns="http://www.w3.org/2000/svg">
    //         <path d="M16.92 8.04999L10.4 1.52999C9.63002 0.759987 8.37002 0.759987 7.60002 1.52999L1.08002 8.04999" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
    //       </svg>
    //     </div>
    //
    //
    //     {/*  dropdown*/}
    //
    //
    //     <div ref={dropDownRef} className={`flex md:flex flex-col !gap-y-3 bottom-0 w-full fixed md:absolute md:top-full mt-2 left-0 w-full bg-white border border-b-0 border-x-0 md:border text-[#6B6B6B] rounded-tr-lg rounded-tl-lg md:rounded-lg transition-all duration-200  shadow-lg z-40 px-2 py-4 ${show ? "fixed -translate-y-0 transition-all md:block md:absolute md:translate-0 md:h-fit"
    //       : "translate-y-full md:-translate-x-0 transition-all md:hidden"}`}>
    //       {optionsList.map(option => (
    //         <div className={classNames('border md:border-0 border-x-0 border-t-0 flex justify-between items-center hover:bg-[#E1E1E1] md:rounded p-1 cursor-pointer',
    //           HOVER_COLORS[color]
    //         )} key={option[id]}>
    //           <p className={'font-bold text-black grow'}
    //              data-name={option[id]}
    //              key={option[id]}
    //              onClick={(event) => handleOptionClick(event)}
    //           >
    //             {option[text]}
    //           </p>
    //           {option[text] === selectedText && <TickIcon/>}
    //         </div>
    //       ))}
    //     </div>
    //
    //   </div>
    //
    //
    // </div>
    //










// multiple choice
//   const [checked, setChecked] = useState([]);
//   const [searchMultipleSelected, setSearchMultipleSelected] = useState<string>('')
//   const checkedLength = checked?.map(item => item).length
//
//   const changeSearchHandler = (e) => {
//     setSearchMultipleSelected(e.target.value)
//   }
//
//   const changeBrandHandler = (id) => {
//     const currentIndex = checked.indexOf(id);
//     const newChecked = [...checked];
//
//     if (currentIndex === -1) {
//       newChecked.push(id);
//     } else {
//       newChecked.splice(currentIndex, 1);
//     }
//     setChecked(newChecked);
//   };
//














  {/*<div ref={wrapperRef} className={'inline-block text-right relative w-full border border-2 border-blue-900'}>*/}
  {/*  <div*/}
  {/*    className={classNames(*/}
  {/*      "flex items-center justify-end cursor-pointer px-3 rounded sm:rounded-md md:rounded-lg z-40",*/}
  {/*      show ? "after:top-2" : "after:content-[''] after:absolute after:z-40 after:right-[10px] after:top-4 after:pt-3 after:border-[7px] after:border-transparent",*/}
  {/*      COLORS[color],*/}
  {/*      SIZES[size],*/}
  {/*      VARIANTS({variants: variant})*/}
  {/*    )}*/}
  {/*    onClick={handleListDisplay}*/}
  {/*  >*/}
  {/*    <p className={'text-right p-0 m-0 text-m-base sm:text-d-xs md:text-d-base'}>{selectedText}</p>*/}
  {/*  </div>*/}
  {/*  {show && (*/}
  {/*    <ul className="bg-danger absolute w-full m-0 mt-1 rounded p-1 bg-white shadow-lg text-right z-[9999999]">*/}
  {/*      {optionsList.map(option => {*/}
  {/*        return (*/}
  {/*          <li*/}
  {/*            className={classNames(*/}
  {/*              "list-none py-1 px-3 my-1 cursor-pointer text-m-base sm:text-d-xs md:text-d-base text-grey-600",*/}
  {/*              HOVER_COLORS[color]*/}
  {/*            )}*/}
  {/*            data-name={option[id]}*/}
  {/*            key={option[id]}*/}
  {/*            onClick={(event) => handleOptionClick(event)}*/}
  {/*          >*/}
  {/*            {option[text]}*/}
  {/*          </li>*/}
  {/*        );*/}
  {/*      })}*/}
  {/*    </ul>*/}
  {/*  )}*/}
  {/*  <div onClick={handleListDisplay} className={'absolute top-1/2 left-4'}>*/}
  {/*    <svg fill={"currentColor"} className={classNames(*/}
  {/*      show ? 'rotate-180 transition-all duration-300' : 'transition-all duration-300',*/}
  {/*      variant === 'contained' ? 'text-white' : `text-${color}`*/}
  {/*    )} xmlns="http://www.w3.org/2000/svg" width="16.431" height="8.226">*/}
  {/*      <path d="M7.5 0a.727.727 0 0 1 .67.423.657.657 0 0 1-.157.746L2.086 6.764a1.973 1.973 0 0 0 0 2.9l5.927 5.595a.658.658 0 0 1 0 .968.756.756 0 0 1-1.026 0L1.06 10.636a3.292 3.292 0 0 1 0-4.84L6.987.2A.748.748 0 0 1 7.5 0z" transform="rotate(-90 4.113 4.113)"/>*/}
  {/*    </svg>*/}
  {/*  </div>*/}
  {/*</div>*/}











  // multiple


  {/*<div ref={wrapperRef} className={classNames('mb-96 flex items-center justify-between rounded-lg relative w-full h-auto',          // COLORS[color],*/}
  {/*  // COLORS[color]*/}
  {/*)}>*/}


  {/*  <div*/}
  {/*    onClick={handleListDisplay}*/}
  {/*    className={classNames('flex justify-between items-center w-full border cursor-pointer rounded-lg px-4 py-4 ',*/}
  {/*      disabled && 'cursor-not-allowed !bg-control-100',*/}
  {/*      COLORS[color],*/}
  {/*      // SIZES[size],*/}
  {/*      VARIANTS({variants: variant})*/}
  {/*    )}>*/}
  {/*    <StartAdornment/>*/}
  {/*    /!*<div className={'flex justify-center items-center h-full !bg-grey-300 w-full'}>*!/*/}
  {/*    <div className={classNames("grow right-[50px] bg-transparent absolute  duration-200",*/}
  {/*      checkedLength >= 1 ? ' duration-200 h-auto translate-y-[-60%] bg-white translate-x-0 right-[9px] top-0' : '',*/}
  {/*      LABEL_SIZES[size]*/}
  {/*    )}*/}
  {/*    >*/}
  {/*      {defaultText}*/}
  {/*    </div>*/}


  {/*    /!*multi select items*!/*/}
  {/*    {checkedLength >= 1 ? (*/}
  {/*      <div className={'flex !justify-start grow flex-wrap gap-x-2'}>*/}
  {/*        {checked?.map(multiSelect => {*/}
  {/*            return (*/}
  {/*              <div className={'bg-control-100'}>*/}
  {/*                {multiSelect}*/}
  {/*              </div>*/}
  {/*            )*/}
  {/*          }*/}
  {/*        )}*/}
  {/*        /!*search multiple selected*!/*/}
  {/*        <input className={''} onChange={changeSearchHandler} value={searchMultipleSelected} placeholder={'جستجو کنید'}/>*/}
  {/*      </div>*/}
  {/*    ):null}*/}


  {/*    /!*</div>*!/*/}

  {/*    /!*{selectedText !== '' && (*!/*/}
  {/*    /!*  <p className={'text-right text-base grow mr-2 text-[#121212]'}>*!/*/}
  {/*    /!*    {selectedText}*!/*/}
  {/*    /!*  </p>*!/*/}
  {/*    /!*)}*!/*/}


  {/*    /!*<ArrowDownIcon show={show}/>*!/*/}
  {/*    <svg className={`${show ? 'rotate-0 duration-150' : 'rotate-180 duration-150'}`} width="18" height="9" viewBox="0 0 18 9" fill="none" xmlns="http://www.w3.org/2000/svg">*/}
  {/*      <path d="M16.92 8.04999L10.4 1.52999C9.63002 0.759987 8.37002 0.759987 7.60002 1.52999L1.08002 8.04999" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>*/}
  {/*    </svg>*/}
  {/*  </div>*/}


  {/*  /!*  dropdown*!/*/}


  {/*  <div ref={dropDownRef} className={`flex md:flex flex-col  bottom-0 w-full fixed md:absolute md:top-full mt-2 left-0 w-full bg-white border border-b-0 border-x-0 md:border text-[#6B6B6B] rounded-tr-lg rounded-tl-lg md:rounded-lg transition-all duration-200  shadow-lg z-40 px-2 py-4 ${show ? "fixed -translate-y-0 transition-all md:block md:absolute md:translate-0 md:h-fit"*/}
  {/*    : "translate-y-full md:-translate-x-0 transition-all md:hidden"}`}>*/}
  {/*    {optionsList.map(option => (*/}
  {/*      <div className={classNames('!py-4 border md:border-0 border-x-0 border-t-0 flex justify-between items-center hover:bg-[#E1E1E1] md:rounded p-1 cursor-pointer',*/}
  {/*        HOVER_COLORS[color]*/}
  {/*      )} key={option[id]}*/}
  {/*           onClick={() => changeBrandHandler(option[text])}*/}
  {/*      >*/}
  {/*        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">*/}
  {/*          <rect x="0.5" y="0.5" width="19" height="19" rx="3.5" stroke="#E1E1E1"/>*/}
  {/*        </svg>*/}

  {/*        <p className={'font-bold text-black grow mr-2'}*/}
  {/*           data-name={option[id]}*/}
  {/*           key={option[id]}*/}
  {/*           onClick={(event) => handleOptionClick(event)}*/}
  {/*        >*/}
  {/*          {option[text]}*/}
  {/*        </p>*/}
  {/*        /!*{option[text] === selectedText && <TickIcon/>}*!/*/}
  {/*      </div>*/}
  {/*    ))}*/}
  {/*  </div>*/}

  {/*</div>*/}


//
//   )
// }