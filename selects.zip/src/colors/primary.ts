const primary = {
  50: "#F3F9FF",
  100: "#E6F2FE",
  200: "#CEE5FE",
  300: "#B5D9FD",
  400: "#9DCCFD",
  500: "#84BFFC",
  600: "#6AA1DB",
  700: "#5084BA",
  800: "#366698",
  900: "#1C4977",
  950: "#0F3A67",
};

module.exports = {
  primary: primary
}
