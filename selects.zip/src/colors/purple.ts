const purple = {
  50: '#F9F0FE',
  100: '#F2E0FE',
  200: '#E5C1FD',
  300: '#D9A3FB',
  400: '#CC84FA',
  500: '#BF65F9',
  600: '#9F51D2',
  700: '#803DAA',
  800: '#602A83',
  900: '#41165B',
  950: '#310C48',
};

module.exports = {
  purple: purple
}
