const orange = {
  50: "#FFF5E5",
  100: "#FFECCC",
  200: "#FFD999",
  300: "#FFC666",
  400: "#FFB333",
  500: "#FFA000",
  600: "#CC8000",
  700: "#996000",
  800: "#664000",
  900: "#332000",
  950: "#1A1000",
};

module.exports = {
  orange: orange
}
