const fs = require('fs')

fs.copyFile('./src/withUiKit.js', './src/dist/withUiKit.js', () => null)